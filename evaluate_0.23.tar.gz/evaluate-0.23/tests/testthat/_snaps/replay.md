# replay() should work when print() returns visible NULLs

    Code
      replay(ret)
    Output
      > structure(1, class = "FOO_BAR")
      NULL

