#' A
#' @export
a <- function() {}

#' B + C
#' @aliases c
#' @export
b <- function() {}
